package model.rules;

public interface IVisible {
    void accept(IVisitor visitor);

}
